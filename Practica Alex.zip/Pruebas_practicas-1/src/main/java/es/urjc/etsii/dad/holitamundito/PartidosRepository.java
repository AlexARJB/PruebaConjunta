package es.urjc.etsii.dad.holitamundito;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PartidosRepository extends JpaRepository<Partidos, Long> {

}
