package es.urjc.etsii.dad.holitamundito;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebasPracticas1Application {

	public static void main(String[] args) {
		SpringApplication.run(PruebasPracticas1Application.class, args);
	}

}
