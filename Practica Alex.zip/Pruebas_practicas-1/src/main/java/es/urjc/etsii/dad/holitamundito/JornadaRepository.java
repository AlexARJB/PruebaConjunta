package es.urjc.etsii.dad.holitamundito;

import org.springframework.data.jpa.repository.JpaRepository;

public interface JornadaRepository extends JpaRepository<Jornada, Long> {

}
